//ExtractorFrames -- StanfordMaxEnt, A Maximum Entropy Toolkit
//Copyright (c) 2002-2011 Leland Stanford Junior University


//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.

//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

//For more information, bug reports, fixes, contact:
//Christopher Manning
//Dept of Computer Science, Gates 1A
//Stanford CA 94305-9010
//USA
//    Support/Questions: java-nlp-user@lists.stanford.edu
//    Licensing: java-nlp-support@lists.stanford.edu
//http://www-nlp.stanford.edu/software/tagger.shtml


package edu.stanford.nlp.tagger.maxent;

import edu.stanford.nlp.util.StringUtils;

import java.util.*;


/**
 * The static eFrames contains
 * an array of all Extractors that are used to define
 * features. This is an important class for the tagger.
 * If you want to add a new Extractor, you should add it to the
 * array eFrames.
 *
 * @author Kristina Toutanova
 * @author Michel Galley
 * @version 1.0
 */
public class ExtractorFrames {

  // all features are implicitly conjoined with the current tag
  static final Extractor cWord = new Extractor(0, false);
  static final Extractor prevWord = new Extractor(-1, false);
  private static final Extractor prevTag = new Extractor(-1, true);
  private static final Extractor prevNextTag = new ExtractorTwoTags(-1, 1);
  // prev tag and current word!
  private static final Extractor prevTagWord = new ExtractorWordTag(0, -1);

  private static final Extractor prevWord2 = new Extractor(-2,false);
  private static final Extractor prevTwoTag = new Extractor(-2,true);
  private static final Extractor nextWord = new Extractor(1, false);
  private static final Extractor nextWord2 = new Extractor(2,false);
  private static final Extractor nextTag = new Extractor(1, true);

  private static final Extractor cWordNextWord = new ExtractorTwoWords(0,1);
  private static final Extractor cWordPrevWord = new ExtractorTwoWords(-1,0);


  // this config was used in the best NAACL 2003 cyclic dependency tagger
  private static final Extractor[] eFrames_bidirectional = {cWord,prevWord,nextWord,prevTag,
      nextTag, new ExtractorContinuousTagConjunction(-2), 
      new ExtractorContinuousTagConjunction(2),prevNextTag,prevTagWord, 
      new ExtractorWordTag(0,1),
      cWordPrevWord,cWordNextWord};
  //  "words(-1,1),order(-2,2),tagConjunction(-1,1),wordTag(0,-1),wordTag(0,1),biwords(-1,1)"

  // features for 2005 SIGHAN tagger
  private static final Extractor[] eFrames_sighan2005 = { cWord, prevWord, prevWord2, nextWord, nextWord2, prevTag, prevTwoTag, new ExtractorContinuousTagConjunction(-2) };

  // features for a german-language bidirectional tagger
  private static final Extractor[] eFrames_german ={ cWord, prevWord, nextWord, nextTag,
      prevTag, new ExtractorContinuousTagConjunction(-2), prevTagWord, cWordPrevWord };

  /**
   * This class is not meant to be instantiated.
   */
  private ExtractorFrames() {
  }


  protected static Extractor[] getExtractorFrames(String arch) {
    // handle some traditional macro options
    // left3words: a simple trigram CMM tagger (similar to the baseline EMNLP 2000 tagger)
    // left5words: a simple trigram CMM tagger, like left3words, with 5 word context
    // generic: our standard multilingual CMM baseline

    arch = arch.replaceAll("left3words", "words(-1,1),order(2)");
    arch = arch.replaceAll("left5words", "words(-2,2),order(2)");
    arch = arch.replaceAll("generic", "words(-1,1),order(2),biwords(-1,0),wordTag(0,-1)");

    ArrayList<Extractor> extrs = new ArrayList<Extractor>();
    List<String> args = StringUtils.valueSplit(arch, "[a-zA-Z0-9]*(?:\\([^)]*\\))?", "\\s*,\\s*");
    for (String arg : args) {
      if (arg.equals("bidirectional")) {
        extrs.addAll(Arrays.asList(eFrames_bidirectional));
      } else if (arg.equals("bidirectional5words")) {
        // like best NAACL 2003 cyclic dependency tagger but adds w_{-2}, w_{+2}
        extrs.addAll(Arrays.asList(eFrames_bidirectional));
        extrs.add(new Extractor(-2, false));
        extrs.add(new Extractor(2, false));
      } else if (arg.equals("sighan2005")) {
        extrs.addAll(Arrays.asList(eFrames_sighan2005));
      } else if (arg.equalsIgnoreCase("german")) {
        extrs.addAll(Arrays.asList(eFrames_german));
      } else if (arg.startsWith("words(")) {
        // non-sequence features with just a certain number of words to the
        // left and right; e.g., words(-2,2) or words(-2,-1)
        int lWindow = Extractor.getParenthesizedNum(arg, 1);
        int rWindow = Extractor.getParenthesizedNum(arg, 2);
        for (int i = lWindow; i <= rWindow; i++) {
          extrs.add(new Extractor(i, false));
        }
      } else if (arg.startsWith("tags(")) {
        // non-sequence features with just a certain number of words to the
        // left and right; e.g., words(-2,2) or words(-2,-1)
        int lWindow = Extractor.getParenthesizedNum(arg, 1);
        int rWindow = Extractor.getParenthesizedNum(arg, 2);
        for (int i = lWindow; i <= rWindow; i++) {
          extrs.add(new Extractor(i, true));
        }
      } else if (arg.startsWith("biwords(")) {
        // non-sequence features of word pairs.
        // biwords(-2,1) would give you 3 extractors for w-2w-1, w-1,w0, w0w1
        int lWindow = Extractor.getParenthesizedNum(arg, 1);
        int rWindow = Extractor.getParenthesizedNum(arg, 2);
        for (int i = lWindow; i < rWindow; i++) {
          extrs.add(new ExtractorTwoWords(i));
        }
      } else if (arg.startsWith("biword(")) {
        // non-sequence feature of a word pair.
        // biwords(-2,1) would give you 1 extractor for w-2, w+1
        int left = Extractor.getParenthesizedNum(arg, 1);
        int right = Extractor.getParenthesizedNum(arg, 2);
        extrs.add(new ExtractorTwoWords(left, right));
      } else if (arg.startsWith("twoTags(")) {
        // non-sequence feature of a tag pair.
        // twoTags(-2,1) would give you 1 extractor for t-2, t+1
        int left = Extractor.getParenthesizedNum(arg, 1);
        int right = Extractor.getParenthesizedNum(arg, 2);
        extrs.add(new ExtractorTwoTags(left, right));
      } else if (arg.startsWith("lowercasewords(")) {
        // non-sequence features with just a certain number of lowercase words
        // to the left and right, and always the current word
        int lWindow = Extractor.getParenthesizedNum(arg, 1);
        int rWindow = Extractor.getParenthesizedNum(arg, 2);
        for (int i = lWindow; i <= rWindow; i++) {
          extrs.add(new ExtractorWordLowerCase(i));
        }
      } else if (arg.startsWith("order(")) {
        // anything like order(2), order(-4), order(0,3), or
        // order(-2,1) are okay.
        int leftOrder = Extractor.getParenthesizedNum(arg, 1);
        int rightOrder = Extractor.getParenthesizedNum(arg, 2);
        if (leftOrder > 0) { leftOrder = -leftOrder; }
	if (rightOrder < 0) { throw new IllegalArgumentException("Right order must be non-negative, not " + rightOrder); }
        // cdm 2009: We only add successively higher order tag k-grams
        // ending adjacent to t0.  Adding lower order features at a distance
        // appears not to help (Dec 2009). But they can now be added with tags().

        for (int idx = leftOrder ; idx <= rightOrder; idx++) {
          if (idx == 0) {
            // do nothing
          } else if (idx == -1 || idx == 1) {
            extrs.add(new Extractor(idx, true));
          } else {
            extrs.add(new ExtractorContinuousTagConjunction(idx));
          }
        }
      } else if (arg.startsWith("wordTag(")) {
        // sequence feature of a word and a tag: wordTag(-1,1)
        int posW = Extractor.getParenthesizedNum(arg, 1);
        int posT = Extractor.getParenthesizedNum(arg, 2);
        extrs.add(new ExtractorWordTag(posW, posT));
      } else if (arg.startsWith("vbn(")) {
        int order = Extractor.getParenthesizedNum(arg, 1);
        extrs.add(new ExtractorVerbalVBNZero(order));
      } else if (arg.startsWith("wordTwoTags(")) {
        int word = Extractor.getParenthesizedNum(arg, 1);
        int tag1 = Extractor.getParenthesizedNum(arg, 2);
        int tag2 = Extractor.getParenthesizedNum(arg, 3);
        extrs.add(new ExtractorWordTwoTags(word,tag1,tag2));
      } else if (arg.startsWith("threeTags(")) {
        int pos1 = Extractor.getParenthesizedNum(arg, 1);
        int pos2 = Extractor.getParenthesizedNum(arg, 2);
        int pos3 = Extractor.getParenthesizedNum(arg, 3);
        extrs.add(new ExtractorThreeTags(pos1,pos2,pos3));
      } else if (arg.equalsIgnoreCase("naacl2003unknowns") || arg.equalsIgnoreCase("lnaacl2003unknowns") || arg.equalsIgnoreCase("naacl2003conjunctions")
              || arg.startsWith("wordshapes(") || arg.startsWith("lwordshapes(") || arg.equalsIgnoreCase("motleyUnknown")
              || arg.startsWith("suffix(") || arg.startsWith("prefix(")
              || arg.startsWith("prefixsuffix") || arg.startsWith("capitalizationsuffix(")
              || arg.startsWith("distsim(") || arg.startsWith("distsimconjunction(")
              || arg.equalsIgnoreCase("lctagfeatures")
              || arg.startsWith("unicodeshapes(") || arg.startsWith("chinesedictionaryfeatures(")
              || arg.startsWith("unicodeshapeconjunction(")) {
        // okay; known unknown keyword
      } else {
        System.err.println("Unrecognized ExtractorFrames identifier (ignored): " + arg);
      }
    } // end for
    return extrs.toArray(new Extractor[extrs.size()]);
  }


  /**
   * This extractor extracts a word and tag in conjunction.
   */
  static class ExtractorWordTag extends Extractor {

    private static final long serialVersionUID = 3L;

    private final int wordPosition;
    public ExtractorWordTag(int posW, int posT) {
      super(posT, true);
      wordPosition = posW;
    }

    @Override
    String extract(History h, PairsHolder pH) {
      return pH.getTag(h, position) + '!' + pH.getWord(h, wordPosition);
    }

    @Override
    public String toString() {
      return (getClass().getName() + "(w" + wordPosition + 
              ",t" + position + ")");
    }
  }


  /**
   * The word in lower-cased version.
   * Always uses Locale.ENGLISH.
   */
  static class ExtractorWordLowerCase extends Extractor {

    private static final long serialVersionUID = -7847524200422095441L;

    public ExtractorWordLowerCase(int position) {
      super(position, false);
    }

    @Override
      String extract(History h, PairsHolder pH) {
      return pH.getWord(h, position).toLowerCase(Locale.ENGLISH);
    }

  }

  /**
   * The current word if it is capitalized, zero otherwise.
   * Always uses Locale.ENGLISH.
   */
  static class ExtractorCWordCapCase extends Extractor {

    private static final long serialVersionUID = -2393096135964969744L;

    @Override
      String extract(History h, PairsHolder pH) {
      String cw = ExtractorFrames.cWord.extract(h, pH);
      String lk = cw.toLowerCase(Locale.ENGLISH);
      if (lk.equals(cw)) {
        return zeroSt;
      }
      return cw;
    }

    @Override public boolean isLocal() { return true; }
    @Override public boolean isDynamic() { return false; }
  }


  /**
   * This extractor extracts two words in conjunction.
   * The one argument constructor gives you leftPosition and
   * leftPosition+1, but with the two argument constructor,
   * they can be any pair of word positions.
   */
  static class ExtractorTwoWords extends Extractor {

    private static final long serialVersionUID = -1034112287022504917L;

    private final int leftPosition;
    private final int rightPosition;

    public ExtractorTwoWords(int leftPosition) {
      this(leftPosition, leftPosition+1);
    }

    public ExtractorTwoWords(int position1, int position2) {
      super(0, false);
      if (position1 > position2) {
        leftPosition = position1;
        rightPosition = position2;
      } else {
        leftPosition = position2;
        rightPosition = position1;
      }
    }

    @Override
      String extract(History h, PairsHolder pH) {
      // I ran a bunch of timing tests that seem to indicate it is
      // cheaper to simply add string + char + string than use a
      // StringBuilder or go through the StringBuildMemoizer -horatio
      return pH.getWord(h, leftPosition) + '!' + pH.getWord(h, rightPosition);
    }

    @Override public boolean isLocal() { return false; }

    // isDynamic --> false, but no need to override


    @Override
    public String toString() {
      return (getClass().getName() + "(w" + leftPosition + 
              ",w" + rightPosition + ")");
    }    
  }



  /**
   * This extractor extracts two tags in conjunction.
   * The one argument constructor gives you leftPosition and
   * leftPosition+1, but with the two argument constructor,
   * they can be any pair of tag positions.
   */
  static class ExtractorTwoTags extends Extractor {

    private static final long serialVersionUID = -7342144764725605134L;

    private final int leftPosition;
    private final int rightPosition;
    private final int leftContext, rightContext;

    public ExtractorTwoTags(int leftPosition) {
      this(leftPosition, leftPosition+1);
    }

    public ExtractorTwoTags(int position1, int position2) {
      leftPosition = Math.min(position1, position2);
      rightPosition = Math.max(position1, position2);

      leftContext = -Math.min(leftPosition, 0);
      rightContext = Math.max(rightPosition, 0);
    }

    @Override
    public int rightContext() {
      return rightContext;
    }

    @Override
    public int leftContext() {
      return leftContext;
    }

    @Override
    String extract(History h, PairsHolder pH) {
      // I ran a bunch of timing tests that seem to indicate it is
      // cheaper to simply add string + char + string than use a
      // StringBuilder or go through the StringBuildMemoizer -horatio
      return pH.getTag(h, leftPosition) + '!' + pH.getTag(h, rightPosition);
    }

    @Override public boolean isLocal() { return false; }
    @Override public boolean isDynamic() { return true; }

    @Override
    public String toString() {
      return (getClass().getName() + "(t" + leftPosition + 
              ",t" + rightPosition + ")");
    }    
  }


  /**
   * This extractor extracts two words and a tag in conjunction.
   */
  static class ExtractorTwoWordsTag extends Extractor {

    private static final long serialVersionUID = 277004119652781188L;

    private final int leftWord, rightWord, tag;
    private final int rightContext, leftContext;

    public ExtractorTwoWordsTag(int leftWord, int rightWord, int tag) {
      this.leftWord = Math.min(leftWord, rightWord);
      this.rightWord = Math.max(leftWord, rightWord);
      this.tag = tag;

      this.rightContext = Math.max(tag, 0);
      this.leftContext = -Math.min(tag, 0);
    }

    @Override
    public int rightContext() {
      return rightContext;
    }

    @Override
    public int leftContext() {
      return leftContext;
    }

    @Override
      String extract(History h, PairsHolder pH) {
      return (pH.getWord(h, leftWord) + '!' + pH.getTag(h, tag) + '!' + 
              pH.getWord(h, rightWord));
    }

    @Override public boolean isLocal() { return false; }
    @Override public boolean isDynamic() { return true; }

    @Override
    public String toString() {
      return (getClass().getName() + "(w" + leftWord + 
              ",t" + tag + ",w" + rightWord + ")");
    }    
  }



  /**
   * This extractor extracts several contiguous tags only on one side of position 0.
   * E.g., use constructor argument -3 for an order 3 predictor on the left.
   * isLocal=false, isDynamic=true (through super call)
   */
  static class ExtractorContinuousTagConjunction extends Extractor {

    private static final long serialVersionUID = 3;

    public ExtractorContinuousTagConjunction(int maxPosition) {
      super(maxPosition, true);
    }

    @Override
    String extract(History h, PairsHolder pH) {
      StringBuilder sb = new StringBuilder();
      if (position < 0) {
        for (int idx = position; idx < 0; idx++) {
          if (idx != position) {
            sb.append('!');
          }
          sb.append(pH.getTag(h, idx));
        }
      } else {
        for (int idx = position; idx > 0; idx--) {
          if (idx != position) {
            sb.append('!');
          }
          sb.append(pH.getTag(h, idx));
        }
      }
      return sb.toString();
    }

  }


  /**
   * This extractor extracts three tags.
   */
  static class ExtractorThreeTags extends Extractor {

    private static final long serialVersionUID = 8563584394721620568L;

    private int position1;
    private int position2;
    private int position3;

    public ExtractorThreeTags(int position1, int position2, int position3) {
      // bubblesort them!
      int x;
      if (position1 > position2) {
        x = position2;
        position2 = position1;
        position1 = x;
      }
      if (position2 > position3) {
        x = position3;
        position3 = position2;
        position2 = x;
      }
      if (position1 > position2) {
        x = position2;
        position2 = position1;
        position1 = x;
      }
      this.position1 = position1;
      this.position2 = position2;
      this.position3 = position3;
    }

    @Override
      public int rightContext() {
      if (position3 > 0) {
        return position3;
      } else {
        return 0;
      }
    }

    @Override
      public int leftContext() {
      if (position1 < 0) {
        return -position1;
      } else {
        return 0;
      }
    }

    @Override
      String extract(History h, PairsHolder pH) {
      return pH.getTag(h, position1) + '!' + pH.getTag(h, position2) + '!' + pH.getTag(h, position3);
    }

    @Override public boolean isLocal() { return false; }
    @Override public boolean isDynamic() { return true; }

    @Override
    public String toString() {
      return (getClass().getName() + "(t" + position1 + 
              ",t" + position2 + ",t" + position3 + ")");
    }    
  }


  /**
   * This extractor extracts two tags and the a word in conjunction.
   */
  static class ExtractorWordTwoTags extends Extractor {

    private static final long serialVersionUID = -4942654091455804176L;

    // We sort so that position1 <= position2 and then rely on that.
    private int position1;
    private int position2;
    private int word;

    public ExtractorWordTwoTags(int word, int position1, int position2) {
      if (position1 < position2) {
        this.position1 = position1;
        this.position2 = position1;
      } else {
        this.position1 = position2;
        this.position2 = position1;
      }
      this.word = word;
    }

    @Override
      public int leftContext() {
      if (position1 < 0) {
        return  -position1;
      } else {
        return 0;
      }
    }

    @Override
      public int rightContext() {
      if (position2 > 0) {
        return position2;
      } else {
        return 0;
      }
    }

    @Override
      String extract(History h, PairsHolder pH) {
      return pH.getTag(h, position1) + '!' + pH.getWord(h, word) + '!' + pH.getTag(h, position2);
    }

    @Override public boolean isLocal() { return false; }
    @Override public boolean isDynamic() { return true; }

    @Override
    public String toString() {
      return (getClass().getName() + "(t" + position1 + 
              ",t" + position2 + ",w" + word + ")");
    }    
  }

} // end class ExtractorFrames
