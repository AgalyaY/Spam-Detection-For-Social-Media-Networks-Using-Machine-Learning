/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author VelyuthaPerumal
 */
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
public class SubstringBetweenTest {

	public static void main(String[] args) throws Exception {

		File file = new File("C:\\Users\\charu nandhini\\Desktop\\project\\as.txt");
		String testHtml = FileUtils.readFileToString(file); // from commons io

		String title = StringUtils.substringBetween(testHtml, "<TEXT>", "</TEXT>");
                
		//System.out.println("title:" + title); // good
try{
    
       Connection con = null;
    Statement st = null;
    String t3, t4 = "";
    ResultSet rs, rs1 = null;
    Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/anntoating", "root", "root");
                st = con.createStatement();
		String[] tds = StringUtils.substringsBetween(testHtml, "<TEXT>", "</TEXT>");
		for (String td : tds) {
           int v = st.executeUpdate(" insert into dataset values ('"+td+"')");
			System.out.println("td value:" + td); // good
                       
		}
}catch(Exception e){
    e.printStackTrace();
}

//		String moreStuff = StringUtils.substringBetween(testHtml, "head");
//		System.out.println("\n'head' to 'head':" + moreStuff); // not so good

	}

}